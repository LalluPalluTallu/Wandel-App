import React from "react";
import ReactDOM from "react-dom/client";
import Wandel from "./Wandel";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Wandel />
  </React.StrictMode>
);

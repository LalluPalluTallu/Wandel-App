import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  Flame, Trophy, Users, Home, User, Dumbbell, GraduationCap, Briefcase, ChevronRight, Plus, Check, Zap, X, Copy, UserPlus, Medal, Award, MessageCircle, Send, Sparkles, PartyPopper, LogOut, Loader2 } from "lucide-react";
import {
  getToken, setToken, clearToken,
  registerUser, loginUser, getProfile,
  getTodayTask, completeTask,
  getLeaderboard,
  getMySquad, createSquad, joinSquad, leaveSquad, sendChatMessage,
} from "./api";

// Brand palette
// bg    #0F110C  base canvas
// card  #191C14  raised surface
// card2 #1F2318  slightly lifted surface (hero cards)
// line  #2A2E20  hairline border
// lime  #C6FF3D  primary accent
// coral #FF6B4A  streak/energy accent
// ink   #6E7263  muted text

const AVATAR_COLORS = ["#C6FF3D", "#FF6B4A", "#5AC8FA", "#FFD84A", "#C792FF"];
function avatarColor(name) {
  const i = name.charCodeAt(0) % AVATAR_COLORS.length;
  return AVATAR_COLORS[i];
}

function Avatar({ name, size = 36 }) {
  const color = avatarColor(name);
  return (
    <div
      className="rounded-full flex items-center justify-center font-extrabold shrink-0"
      style={{ width: size, height: size, background: `${color}22`, color, fontSize: size * 0.38 }}
    >
      {name[0].toUpperCase()}
    </div>
  );
}

function ProgressRing({ pct, size = 84, stroke = 8 }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} strokeWidth={stroke} fill="none" className="stroke-white/10" />
        <circle
          cx={size / 2} cy={size / 2} r={r} strokeWidth={stroke} fill="none"
          strokeDasharray={c} strokeDashoffset={c - (pct / 100) * c}
          strokeLinecap="round" transform={`rotate(-90 ${size / 2} ${size / 2})`}
          className="stroke-[#C6FF3D] transition-all duration-700 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-sm font-extrabold text-white">{pct}%</span>
      </div>
    </div>
  );
}

// NOTE: the backend has no "daily activity history" endpoint yet, so this
// heatmap stays illustrative/random. Add a GET /api/profile/history-style
// endpoint (list of dates with a completion) to make this real.
function StreakHeatmap() {
  const days = useMemo(() => Array.from({ length: 35 }, () => Math.random() > 0.32), []);
  return (
    <div className="grid grid-cols-7 gap-[5px]">
      {days.map((active, i) => (
        <div
          key={i}
          className={`aspect-square rounded-[4px] ${active ? "bg-[#C6FF3D]" : "bg-white/[0.06]"}`}
          style={{ opacity: active ? 0.45 + (i / 35) * 0.55 : 1 }}
        />
      ))}
    </div>
  );
}

// Generic celebration popup — used for streak milestones, badge unlocks, level-ups.
// kind: "streak" | "badge" | "levelup"
function CelebrationModal({ kind, data, onClose }) {
  const config = {
    streak: {
      icon: Flame,
      color: "#FF6B4A",
      title: `${data?.days ?? 7}-day streak!`,
      subtitle: "You're on fire. Don't break the chain now.",
    },
    badge: {
      icon: Trophy,
      color: "#FFD84A",
      title: data?.label ?? "New badge unlocked",
      subtitle: "Added to your profile — show it off.",
    },
    levelup: {
      icon: Sparkles,
      color: "#C6FF3D",
      title: `Level ${data?.level ?? 2} reached`,
      subtitle: "New daily tasks just got unlocked.",
    },
  }[kind];

  if (!config) return null;
  const Icon = config.icon;

  return (
    <div onClick={onClose} className="absolute inset-0 bg-black/65 backdrop-blur-[2px] flex items-center justify-center z-20 px-6">
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full bg-[#12140F] rounded-[28px] border border-[#2A2E20] p-7 text-center relative overflow-hidden animate-[pop_0.25s_ease-out]"
      >
        <div
          className="absolute -top-10 -right-10 w-32 h-32 rounded-full opacity-20"
          style={{ background: config.color }}
        />
        <button onClick={onClose} className="absolute top-3 right-3 text-[#8B8F7A] p-1.5 rounded-full hover:bg-white/5">
          <X size={16} />
        </button>
        <div
          className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center relative"
          style={{ background: `${config.color}22` }}
        >
          <Icon size={30} style={{ color: config.color }} fill={kind === "streak" ? config.color : "none"} fillOpacity={0.25} />
        </div>
        <h2 className="text-white text-[20px] font-extrabold mb-1.5 tracking-tight">{config.title}</h2>
        <p className="text-[#9AA085] text-[13.5px] mb-6 leading-relaxed">{config.subtitle}</p>
        <button
          onClick={onClose}
          className="w-full py-3.5 rounded-2xl font-extrabold text-[14.5px] transition-transform active:scale-[0.98]"
          style={{ background: config.color, color: "#0F110C" }}
        >
          Nice!
        </button>
      </div>
    </div>
  );
}

// Floating AI chatbot bubble + panel. UI shell only — the backend has no
// chat endpoint yet. Add one (e.g. POST /api/chat) and swap the `send`
// function below to call it.
function AIChatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { from: "bot", text: "Hey! I'm your Wandel coach. Ask me for a quick workout, nutrition tip, or motivation." },
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, open]);

  const send = async () => {
    const message = input.trim();
    if (!message) return;
    setMessages((m) => [...m, { from: "user", text: message }]);
    setInput("");
    try {
      const data = await sendChatMessage(message);
      setMessages((m) => [...m, { from: "bot", text: data.response || "I couldn't generate a response right now." }]);
    } catch (err) {
      setMessages((m) => [...m, { from: "bot", text: "Sorry, I couldn't reach the AI coach right now." }]);
    }
  };

  return (
    <>
      {open && (
        <div className="absolute inset-0 bg-black/50 z-20 flex items-end" onClick={() => setOpen(false)}>
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full bg-[#12140F] rounded-t-[28px] border border-[#2A2E20] border-b-0 h-[70%] flex flex-col"
          >
            <div className="flex items-center justify-between px-5 pt-5 pb-3 border-b border-[#2A2E20]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#C6FF3D]/15 flex items-center justify-center">
                  <Sparkles size={15} className="text-[#C6FF3D]" />
                </div>
                <span className="text-white font-extrabold text-[15px]">Wandel Coach</span>
              </div>
              <button onClick={() => setOpen(false)} className="text-[#8B8F7A] p-1.5 rounded-full hover:bg-white/5">
                <X size={18} />
              </button>
            </div>
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-3">
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-[13.5px] leading-snug ${
                    m.from === "user"
                      ? "bg-[#C6FF3D] text-[#0F110C] self-end font-semibold"
                      : "bg-[#191C14] border border-[#2A2E20] text-[#D6D9C9] self-start"
                  }`}
                >
                  {m.text}
                </div>
              ))}
            </div>
            <div className="flex items-center gap-2 px-4 py-3.5 border-t border-[#2A2E20]">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
                placeholder="Ask your coach anything..."
                className="flex-1 bg-[#191C14] border border-[#2A2E20] rounded-full px-4 py-2.5 text-white text-[13.5px] placeholder:text-[#6E7263] focus:outline-none focus:border-[#C6FF3D]/60"
              />
              <button
                onClick={send}
                className="w-10 h-10 rounded-full bg-[#C6FF3D] flex items-center justify-center shrink-0 transition-transform active:scale-90"
              >
                <Send size={16} className="text-[#0F110C]" />
              </button>
            </div>
          </div>
        </div>
      )}
      <button
        onClick={() => setOpen(true)}
        className="absolute bottom-24 right-4 w-13 h-13 rounded-full bg-[#C6FF3D] shadow-lg flex items-center justify-center z-10 transition-transform active:scale-90"
        style={{ width: 52, height: 52 }}
      >
        <MessageCircle size={22} className="text-[#0F110C]" />
      </button>
    </>
  );
}

function NavBar({ tab, setTab }) {
  const items = [
    { id: "home", icon: Home, label: "Home" },
    { id: "leaderboard", icon: Trophy, label: "Ranks" },
    { id: "squad", icon: Users, label: "Squad" },
    { id: "profile", icon: User, label: "Profile" },
  ];
  return (
    <div className="flex justify-around border-t border-[#2A2E20] bg-[#0F110C] pt-2.5 pb-4 sticky bottom-0">
      {items.map(({ id, icon: Icon, label }) => {
        const active = tab === id;
        return (
          <button
            key={id}
            onClick={() => setTab(id)}
            className="flex flex-col items-center gap-1 transition-transform active:scale-90"
          >
            <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${active ? "bg-[#C6FF3D]/15" : ""}`}>
              <Icon size={19} strokeWidth={2.2} className={active ? "text-[#C6FF3D]" : "text-[#6E7263]"} />
            </div>
            <span className={`text-[10px] font-bold ${active ? "text-[#C6FF3D]" : "text-[#6E7263]"}`}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Auth: sign-up (register) collects name + email + password + role, then
// registers against POST /api/auth/register. Existing users can switch to
// the login form (POST /api/auth/login). Both store the JWT and fetch the
// real profile before handing control back to the app.
// ---------------------------------------------------------------------------
function Onboarding({ onDone }) {
  const [mode, setMode] = useState("signup"); // "signup" | "login"
  const [step, setStep] = useState(0);
  const [role, setRole] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const roleTasks = {
    student: [
      "Beat sedentary study sessions with 5-min movement breaks",
      "Squad up with classmates for hostel and campus challenges",
      "Earn XP for walking between classes",
    ],
    working: [
      "Fit workouts around meetings with quick desk-break tasks",
      "Compete with coworkers in a weekly office squad",
      "Track standing and walking during your workday",
    ],
  };

  const finishAuth = async (token) => {
    setToken(token);
    const profile = await getProfile();
    onDone(profile);
  };

  const handleRegister = async () => {
    setError("");
    setSubmitting(true);
    try {
      const { access_token } = await registerUser({ name: name.trim(), email: email.trim(), password, role });
      await finishAuth(access_token);
    } catch (err) {
      setError(err.message || "Something went wrong. Try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleLogin = async () => {
    setError("");
    setSubmitting(true);
    try {
      const { access_token } = await loginUser({ email: email.trim(), password });
      await finishAuth(access_token);
    } catch (err) {
      setError(err.message || "Invalid email or password.");
    } finally {
      setSubmitting(false);
    }
  };

  if (mode === "login") {
    return (
      <div className="min-h-[520px] flex flex-col justify-center px-1">
        <div className="w-14 h-14 rounded-2xl bg-[#C6FF3D] flex items-center justify-center mb-5 rotate-[-4deg]">
          <Dumbbell size={26} className="text-[#0F110C]" strokeWidth={2.4} />
        </div>
        <h1 className="text-[28px] font-extrabold text-white mb-2 tracking-tight leading-none">Welcome back</h1>
        <p className="text-[#9AA085] text-[14.5px] leading-relaxed mb-6">Log in to pick up your streak.</p>

        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          type="email"
          className="w-full px-4 py-4 rounded-2xl border border-[#2A2E20] bg-[#191C14] text-white text-[15px] mb-3 placeholder:text-[#6E7263] focus:outline-none focus:border-[#C6FF3D]/60"
        />
        <input
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          type="password"
          onKeyDown={(e) => e.key === "Enter" && handleLogin()}
          className="w-full px-4 py-4 rounded-2xl border border-[#2A2E20] bg-[#191C14] text-white text-[15px] mb-3 placeholder:text-[#6E7263] focus:outline-none focus:border-[#C6FF3D]/60"
        />
        {error && <p className="text-[#FF6B4A] text-[12.5px] mb-3">{error}</p>}
        <button
          disabled={!email.trim() || !password || submitting}
          onClick={handleLogin}
          className={`w-full py-4 rounded-2xl font-extrabold text-[15px] flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] ${
            email.trim() && password ? "bg-[#C6FF3D] text-[#0F110C]" : "bg-[#191C14] text-[#4E523F] border border-[#2A2E20]"
          }`}
        >
          {submitting ? <Loader2 size={16} className="animate-spin" /> : <>Log in <ChevronRight size={17} /></>}
        </button>
        <button onClick={() => { setMode("signup"); setError(""); }} className="w-full text-[#8B8F7A] text-[12.5px] font-bold py-3 mt-1">
          New here? Create an account
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-[520px] flex flex-col justify-center px-1">
      <div className="flex gap-1.5 mb-8">
        {[0, 1, 2].map((s) => (
          <div key={s} className={`h-1 rounded-full flex-1 transition-colors ${s <= step ? "bg-[#C6FF3D]" : "bg-white/10"}`} />
        ))}
      </div>

      {step === 0 && (
        <div>
          <div className="w-14 h-14 rounded-2xl bg-[#C6FF3D] flex items-center justify-center mb-5 rotate-[-4deg]">
            <Dumbbell size={26} className="text-[#0F110C]" strokeWidth={2.4} />
          </div>
          <h1 className="text-[34px] font-extrabold text-white mb-2 tracking-tight leading-none">Wandel</h1>
          <p className="text-[#9AA085] text-[16px] leading-relaxed mb-8 max-w-[280px]">
            Build streaks, climb ranks, move with your squad.
          </p>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="What should we call you?"
            className="w-full px-4 py-4 rounded-2xl border border-[#2A2E20] bg-[#191C14] text-white text-[15px] mb-3 placeholder:text-[#6E7263] focus:outline-none focus:border-[#C6FF3D]/60 transition-colors"
          />
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            type="email"
            className="w-full px-4 py-4 rounded-2xl border border-[#2A2E20] bg-[#191C14] text-white text-[15px] mb-3 placeholder:text-[#6E7263] focus:outline-none focus:border-[#C6FF3D]/60 transition-colors"
          />
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password (min 8 characters)"
            type="password"
            className="w-full px-4 py-4 rounded-2xl border border-[#2A2E20] bg-[#191C14] text-white text-[15px] mb-4 placeholder:text-[#6E7263] focus:outline-none focus:border-[#C6FF3D]/60 transition-colors"
          />
          <button
            disabled={!name.trim() || !email.trim() || password.length < 8}
            onClick={() => setStep(1)}
            className={`w-full py-4 rounded-2xl font-extrabold text-[15px] flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] ${
              name.trim() && email.trim() && password.length >= 8 ? "bg-[#C6FF3D] text-[#0F110C]" : "bg-[#191C14] text-[#4E523F] border border-[#2A2E20]"
            }`}
          >
            Continue <ChevronRight size={17} />
          </button>
          <button onClick={() => setMode("login")} className="w-full text-[#8B8F7A] text-[12.5px] font-bold py-3">
            Already have an account? Log in
          </button>
        </div>
      )}

      {step === 1 && (
        <div>
          <h2 className="text-[24px] font-extrabold text-white mb-2 tracking-tight">Hey {name.split(" ")[0] || "there"} 👋</h2>
          <p className="text-[#9AA085] text-[14.5px] mb-6 leading-relaxed">
            Are you a student or working professional? We'll tailor your daily tasks around your routine.
          </p>
          <div className="flex flex-col gap-3">
            {[
              { id: "student", icon: GraduationCap, title: "Student", sub: "Classes, hostel life, campus energy", color: "#5AC8FA" },
              { id: "working", icon: Briefcase, title: "Working professional", sub: "Meetings, desk time, office life", color: "#FFD84A" },
            ].map(({ id, icon: Icon, title, sub, color }) => (
              <button
                key={id}
                onClick={() => { setRole(id); setStep(2); }}
                className="flex items-center gap-4 p-4 rounded-2xl border border-[#2A2E20] bg-[#191C14] text-left transition-all hover:border-[#3A3F2C] active:scale-[0.98]"
              >
                <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${color}20` }}>
                  <Icon size={22} style={{ color }} />
                </div>
                <div className="flex-1">
                  <div className="text-white font-bold text-[15px]">{title}</div>
                  <div className="text-[#8B8F7A] text-[12.5px] mt-0.5">{sub}</div>
                </div>
                <ChevronRight size={16} className="text-[#4E523F]" />
              </button>
            ))}
          </div>
        </div>
      )}

      {step === 2 && role && (
        <div>
          <div className="inline-flex items-center gap-1.5 bg-[#C6FF3D]/15 text-[#C6FF3D] text-[12px] font-extrabold px-3 py-1.5 rounded-full mb-5">
            <Check size={13} /> {role === "student" ? "Student mode" : "Working professional mode"}
          </div>
          <h2 className="text-[22px] font-extrabold text-white mb-5 tracking-tight">Your daily tasks will include</h2>
          <div className="flex flex-col gap-2.5 mb-8">
            {roleTasks[role].map((t, i) => (
              <div key={i} className="flex gap-3 items-start p-4 bg-[#191C14] rounded-2xl border border-[#2A2E20]">
                <div className="w-7 h-7 rounded-lg bg-[#C6FF3D]/15 flex items-center justify-center shrink-0 mt-0.5">
                  <Zap size={14} className="text-[#C6FF3D]" />
                </div>
                <span className="text-[#D6D9C9] text-[14px] leading-snug pt-1">{t}</span>
              </div>
            ))}
          </div>
          {error && <p className="text-[#FF6B4A] text-[12.5px] mb-3">{error}</p>}
          <button
            disabled={submitting}
            onClick={handleRegister}
            className="w-full py-4 rounded-2xl bg-[#C6FF3D] text-[#0F110C] font-extrabold text-[15px] transition-all active:scale-[0.98] flex items-center justify-center gap-2"
          >
            {submitting ? <Loader2 size={16} className="animate-spin" /> : "Start my first streak"}
          </button>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Home: pulls today's recommended task from GET /api/tasks/today and marks
// it complete via POST /api/tasks/{id}/complete, then refreshes the shared
// profile (xp/streak) held in the parent.
// ---------------------------------------------------------------------------
function HomeScreen({ profile, refreshProfile }) {
  const isStudent = profile.role === "student";
  const [celebration, setCelebration] = useState(null);
  const [task, setTask] = useState(null);
  const [taskState, setTaskState] = useState("loading"); // loading | ready | done | error | empty
  const [error, setError] = useState("");
  const [marking, setMarking] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setTaskState("loading");
    getTodayTask()
      .then(({ task }) => {
        if (cancelled) return;
        setTask(task);
        setTaskState("ready");
      })
      .catch((err) => {
        if (cancelled) return;
        if (err.status === 404) setTaskState("empty");
        else {
          setError(err.message);
          setTaskState("error");
        }
      });
    return () => { cancelled = true; };
  }, []);

  const markDone = async () => {
    if (!task || marking) return;
    setMarking(true);
    try {
      const result = await completeTask(task.id);
      setTaskState("done");
      await refreshProfile();
      if (!result.already_completed && result.current_streak > 0 && result.current_streak % 7 === 0) {
        setCelebration({ kind: "streak", data: { days: result.current_streak } });
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setMarking(false);
    }
  };

  const streakPct = profile.longest_streak > 0
    ? Math.min(100, Math.round((profile.current_streak / profile.longest_streak) * 100))
    : profile.current_streak > 0 ? 100 : 0;

  return (
    <div className="px-1 pb-5">
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-[#8B8F7A] text-[13px] mb-0.5">Welcome back</p>
          <h1 className="text-white text-[24px] font-extrabold tracking-tight">{profile.name.split(" ")[0]}</h1>
        </div>
        <Avatar name={profile.name} size={42} />
      </div>

      <div className="rounded-[28px] p-5 mb-4 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1F2318 0%, #191C14 100%)" }}>
        <div className="absolute -right-6 -top-6 w-28 h-28 rounded-full bg-[#FF6B4A]/10" />
        <div className="flex items-center justify-between relative">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Flame size={20} className="text-[#FF6B4A]" fill="#FF6B4A" fillOpacity={0.25} />
              <span className="text-[#8B8F7A] text-[12.5px] font-semibold">Current streak</span>
            </div>
            <div className="text-white text-[40px] font-extrabold leading-none tracking-tight">
              {profile.current_streak}<span className="text-[16px] text-[#8B8F7A] font-bold ml-1.5">days</span>
            </div>
            <p className="text-[#6E7263] text-[12px] mt-2">Your longest run is {profile.longest_streak} days — keep going.</p>
          </div>
          <ProgressRing pct={streakPct} size={72} stroke={7} />
        </div>
      </div>

      <div className="rounded-[24px] p-4.5 mb-4 border border-[#3A4A24] relative overflow-hidden" style={{ background: "linear-gradient(120deg, #1E2415 0%, #191C14 70%)" }}>
        {taskState === "loading" && (
          <div className="flex items-center gap-2 text-[#9AA085] text-[13.5px] py-3">
            <Loader2 size={16} className="animate-spin" /> Finding today's task...
          </div>
        )}
        {taskState === "empty" && (
          <p className="text-[#9AA085] text-[13.5px] py-3">No tasks available for your role yet.</p>
        )}
        {taskState === "error" && (
          <p className="text-[#FF6B4A] text-[13.5px] py-3">{error}</p>
        )}
        {(taskState === "ready" || taskState === "done") && task && (
          <>
            <div className="flex justify-between items-center mb-2">
              <span className="inline-flex items-center gap-1.5 text-[#C6FF3D] text-[11px] font-extrabold tracking-wide">
                <Zap size={12} fill="#C6FF3D" /> {isStudent ? "STUDENT TASK" : "WORKDAY TASK"}
              </span>
              <span className="text-[#C6FF3D] text-[12.5px] font-extrabold">+{task.xp} XP</span>
            </div>
            <div className="text-white text-[16px] font-bold mb-3.5 leading-snug">{task.title}</div>
            <button
              onClick={markDone}
              disabled={taskState === "done" || marking}
              className={`w-full py-3 rounded-xl font-extrabold text-[13.5px] transition-transform active:scale-[0.98] flex items-center justify-center gap-2 ${
                taskState === "done" ? "bg-[#2A2E20] text-[#9AA085]" : "bg-[#C6FF3D] text-[#0F110C]"
              }`}
            >
              {marking ? <Loader2 size={15} className="animate-spin" /> : taskState === "done" ? <><Check size={15} /> Done for today</> : "Mark done"}
            </button>
          </>
        )}
      </div>

      {celebration && (
        <CelebrationModal kind={celebration.kind} data={celebration.data} onClose={() => setCelebration(null)} />
      )}

      <div className="flex justify-between items-center mb-2.5">
        <span className="text-white font-bold text-[14px]">This month</span>
        <span className="text-[#6E7263] text-[12px]">Total XP: {profile.total_xp}</span>
      </div>
      <div className="bg-[#191C14] border border-[#2A2E20] rounded-[20px] p-4">
        <StreakHeatmap />
      </div>
    </div>
  );
}

function RankBadge({ rank }) {
  const styles = {
    1: { bg: "#FFD84A22", color: "#FFD84A" },
    2: { bg: "#C9CFD822", color: "#C9CFD8" },
    3: { bg: "#FF6B4A22", color: "#FF6B4A" },
  };
  const s = styles[rank];
  if (!s) return <div className="w-7 text-center text-[#6E7263] font-extrabold text-[13px]">{rank}</div>;
  return (
    <div className="w-7 h-7 rounded-full flex items-center justify-center shrink-0" style={{ background: s.bg }}>
      <Medal size={14} style={{ color: s.color }} />
    </div>
  );
}

// Pulls from GET /api/leaderboard?view=global|squad
function LeaderboardScreen({ profile }) {
  const [view, setView] = useState("global");
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    getLeaderboard(view)
      .then((rows) => { if (!cancelled) setEntries(rows); })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [view]);

  return (
    <div className="px-1 pb-5">
      <h1 className="text-white text-[22px] font-extrabold mb-4 tracking-tight">Leaderboard</h1>
      <div className="flex gap-1.5 mb-5 bg-[#191C14] p-1 rounded-2xl border border-[#2A2E20]">
        {["global", "squad"].map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`flex-1 py-2.5 rounded-xl font-bold text-[12.5px] capitalize transition-colors ${
              view === v ? "bg-[#C6FF3D] text-[#0F110C]" : "text-[#8B8F7A]"
            }`}
          >
            {v}
          </button>
        ))}
      </div>
      {loading && (
        <div className="flex items-center gap-2 text-[#9AA085] text-[13.5px] py-6 justify-center">
          <Loader2 size={16} className="animate-spin" /> Loading...
        </div>
      )}
      {error && <p className="text-[#FF6B4A] text-[13.5px] py-3">{error}</p>}
      {!loading && !error && entries.length === 0 && (
        <p className="text-[#9AA085] text-[13.5px] py-6 text-center">
          {view === "squad" ? "Join a squad to see this ranking." : "No one on the leaderboard yet."}
        </p>
      )}
      <div className="flex flex-col gap-1">
        {entries.map((p) => (
          <div
            key={p.user_id}
            className={`flex items-center gap-3 px-3 py-3 rounded-2xl ${p.me ? "bg-[#C6FF3D]/[0.08] border border-[#C6FF3D]/25" : ""}`}
          >
            <RankBadge rank={p.rank} />
            <Avatar name={p.name} size={34} />
            <div className={`flex-1 text-[14px] ${p.me ? "text-white font-extrabold" : "text-[#D6D9C9] font-medium"}`}>
              {p.name}{p.me && <span className="text-[#C6FF3D]"> · you</span>}
            </div>
            <div className="text-[#8B8F7A] text-[13px] font-bold">{p.xp.toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Create/join a squad via POST /api/squads and POST /api/squads/join.
function SquadModal({ squad, onClose, onChanged }) {
  const [mode, setMode] = useState("invite");
  const [squadName, setSquadName] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const copyCode = () => {
    if (squad?.invite_code) navigator.clipboard?.writeText(squad.invite_code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleCreate = async () => {
    setError("");
    setSubmitting(true);
    try {
      await createSquad(squadName.trim());
      onChanged();
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleJoin = async () => {
    setError("");
    setSubmitting(true);
    try {
      await joinSquad(joinCode.trim());
      onChanged();
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div onClick={onClose} className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex items-end z-10">
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full bg-[#12140F] rounded-t-[28px] border border-[#2A2E20] border-b-0 p-5 pb-7 box-border"
      >
        <div className="w-9 h-1 rounded-full bg-[#2A2E20] mx-auto mb-4" />
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-white text-[18px] font-extrabold tracking-tight">
            {mode === "invite" ? `Invite to ${squad?.name ?? "your squad"}` : mode === "create" ? "Create a squad" : "Join a squad"}
          </h2>
          <button onClick={onClose} className="text-[#8B8F7A] p-1.5 rounded-full hover:bg-white/5">
            <X size={18} />
          </button>
        </div>

        {mode === "invite" && squad && (
          <div>
            <p className="text-[#9AA085] text-[13.5px] mb-4 leading-relaxed">
              Share this code. Anyone who enters it joins {squad.name} instantly.
            </p>
            <div className="flex items-center justify-between bg-[#191C14] border border-[#2A2E20] rounded-2xl px-4 py-4 mb-3.5">
              <span className="text-[#C6FF3D] text-[18px] font-extrabold tracking-wider">{squad.invite_code}</span>
              <button onClick={copyCode} className="text-[#D6D9C9] flex items-center gap-1.5 text-[12.5px] font-bold bg-white/5 px-2.5 py-1.5 rounded-lg">
                <Copy size={13} /> {copied ? "Copied" : "Copy"}
              </button>
            </div>
            <div className="flex gap-2 border-t border-[#2A2E20] pt-4">
              <button
                onClick={() => setMode("create")}
                className="flex-1 border border-[#2A2E20] rounded-xl text-[#9AA085] text-[12.5px] font-bold py-3 hover:bg-white/5"
              >
                Create new squad
              </button>
              <button
                onClick={() => setMode("join")}
                className="flex-1 border border-[#2A2E20] rounded-xl text-[#9AA085] text-[12.5px] font-bold py-3 hover:bg-white/5"
              >
                Join a squad
              </button>
            </div>
          </div>
        )}

        {mode === "invite" && !squad && (
          <div className="flex flex-col gap-2">
            <button
              onClick={() => setMode("create")}
              className="w-full py-4 rounded-2xl bg-[#C6FF3D] text-[#0F110C] font-extrabold text-[14.5px] transition-transform active:scale-[0.98]"
            >
              Create a squad
            </button>
            <button
              onClick={() => setMode("join")}
              className="w-full border border-[#2A2E20] rounded-2xl text-[#9AA085] text-[13px] font-bold py-3.5 hover:bg-white/5"
            >
              Join with an invite code
            </button>
          </div>
        )}

        {mode === "create" && (
          <div>
            {squad && (
              <p className="text-[#9AA085] text-[13.5px] mb-4 leading-relaxed">
                You'll leave {squad.name} and start a fresh squad as its captain.
              </p>
            )}
            <input
              value={squadName}
              onChange={(e) => setSquadName(e.target.value)}
              placeholder="Squad name"
              className="w-full px-4 py-4 rounded-2xl border border-[#2A2E20] bg-[#191C14] text-white text-[14.5px] mb-3.5 placeholder:text-[#6E7263] focus:outline-none focus:border-[#C6FF3D]/60 box-border"
            />
            {error && <p className="text-[#FF6B4A] text-[12.5px] mb-3">{error}</p>}
            <button
              disabled={!squadName.trim() || submitting}
              onClick={handleCreate}
              className={`w-full py-4 rounded-2xl font-extrabold text-[14.5px] mb-2.5 transition-all active:scale-[0.98] flex items-center justify-center gap-2 ${
                squadName.trim() ? "bg-[#C6FF3D] text-[#0F110C]" : "bg-[#191C14] text-[#4E523F] border border-[#2A2E20]"
              }`}
            >
              {submitting ? <Loader2 size={15} className="animate-spin" /> : "Create squad"}
            </button>
            <button onClick={() => setMode("invite")} className="w-full text-[#8B8F7A] text-[12.5px] font-bold py-2">
              Back
            </button>
          </div>
        )}

        {mode === "join" && (
          <div>
            <p className="text-[#9AA085] text-[13.5px] mb-4 leading-relaxed">
              Enter a squad's invite code{squad ? `. You'll leave ${squad.name} to join.` : "."}
            </p>
            <input
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              placeholder="e.g. RUNNERS-9F3X"
              className="w-full px-4 py-4 rounded-2xl border border-[#2A2E20] bg-[#191C14] text-white text-[14.5px] mb-3.5 tracking-wide placeholder:text-[#6E7263] focus:outline-none focus:border-[#C6FF3D]/60 box-border"
            />
            {error && <p className="text-[#FF6B4A] text-[12.5px] mb-3">{error}</p>}
            <button
              disabled={!joinCode.trim() || submitting}
              onClick={handleJoin}
              className={`w-full py-4 rounded-2xl font-extrabold text-[14.5px] mb-2.5 flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] ${
                joinCode.trim() ? "bg-[#C6FF3D] text-[#0F110C]" : "bg-[#191C14] text-[#4E523F] border border-[#2A2E20]"
              }`}
            >
              {submitting ? <Loader2 size={15} className="animate-spin" /> : <><UserPlus size={15} /> Join squad</>}
            </button>
            <button onClick={() => setMode("invite")} className="w-full text-[#8B8F7A] text-[12.5px] font-bold py-2">
              Back
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// Pulls the caller's squad via GET /api/squads/mine (null if not in one).
function SquadScreen({ profile }) {
  const [squad, setSquad] = useState(undefined); // undefined = loading, null = none
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState("");
  const [leaving, setLeaving] = useState(false);

  const refresh = () => {
    setError("");
    getMySquad()
      .then(setSquad)
      .catch((err) => setError(err.message));
  };

  useEffect(refresh, []);

  const handleLeave = async () => {
    setLeaving(true);
    try {
      await leaveSquad();
      refresh();
    } catch (err) {
      setError(err.message);
    } finally {
      setLeaving(false);
    }
  };

  if (squad === undefined) {
    return (
      <div className="flex items-center gap-2 text-[#9AA085] text-[13.5px] py-10 justify-center">
        <Loader2 size={16} className="animate-spin" /> Loading squad...
      </div>
    );
  }

  if (error) return <p className="text-[#FF6B4A] text-[13.5px] py-3 px-1">{error}</p>;

  if (!squad) {
    return (
      <div className="px-1 pb-5 flex flex-col items-center text-center pt-10">
        <div className="w-14 h-14 rounded-2xl bg-[#C6FF3D]/15 flex items-center justify-center mb-4">
          <Users size={26} className="text-[#C6FF3D]" />
        </div>
        <h2 className="text-white text-[18px] font-extrabold mb-2">No squad yet</h2>
        <p className="text-[#9AA085] text-[13.5px] mb-6 leading-relaxed max-w-[260px]">
          Create a squad or join one with an invite code to compete together.
        </p>
        <button
          onClick={() => setShowModal(true)}
          className="w-full py-3.5 rounded-2xl bg-[#C6FF3D] text-[#0F110C] font-extrabold text-[13.5px]"
        >
          Create or join a squad
        </button>
        {showModal && <SquadModal squad={null} onClose={() => setShowModal(false)} onChanged={refresh} />}
      </div>
    );
  }

  return (
    <div className="px-1 pb-5 relative">
      <div className="rounded-[28px] p-5 mb-5 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1F2318 0%, #191C14 100%)" }}>
        <div className="absolute -right-8 -bottom-8 w-32 h-32 rounded-full bg-[#C6FF3D]/[0.06]" />
        <div className="flex items-center gap-3 mb-4 relative">
          <div className="w-12 h-12 rounded-2xl bg-[#C6FF3D]/15 flex items-center justify-center">
            <Award size={22} className="text-[#C6FF3D]" />
          </div>
          <div>
            <h1 className="text-white text-[20px] font-extrabold tracking-tight leading-none">{squad.name}</h1>
            <p className="text-[#8B8F7A] text-[12.5px] mt-1">Invite code: {squad.invite_code}</p>
          </div>
        </div>
        <div className="flex gap-6 relative">
          <div>
            <div className="text-white text-[22px] font-extrabold leading-none">{squad.xp.toLocaleString()}</div>
            <div className="text-[#8B8F7A] text-[11px] mt-1">squad XP</div>
          </div>
          <div>
            <div className="text-white text-[22px] font-extrabold leading-none">{squad.members.length}</div>
            <div className="text-[#8B8F7A] text-[11px] mt-1">members</div>
          </div>
        </div>
      </div>

      <div className="mb-2.5 text-white font-bold text-[14px]">Squad ranking</div>
      <div className="flex flex-col gap-1 mb-5">
        {squad.members.map((m) => (
          <div
            key={m.user_id}
            className={`flex items-center gap-3 px-3 py-3 rounded-2xl ${m.user_id === profile.id ? "bg-[#C6FF3D]/[0.08] border border-[#C6FF3D]/25" : ""}`}
          >
            <RankBadge rank={m.rank} />
            <Avatar name={m.name} size={34} />
            <div className={`flex-1 text-[14px] ${m.user_id === profile.id ? "text-white font-extrabold" : "text-[#D6D9C9] font-medium"}`}>
              {m.name}{m.user_id === profile.id && <span className="text-[#C6FF3D]"> · you</span>}
            </div>
            <div className="text-[#8B8F7A] text-[13px] font-bold">{m.xp.toLocaleString()}</div>
          </div>
        ))}
      </div>

      <button
        onClick={() => setShowModal(true)}
        className="w-full py-3.5 rounded-2xl border border-dashed border-[#3A3F2C] text-[#9AA085] font-bold text-[13px] flex items-center justify-center gap-1.5 hover:bg-white/[0.03] transition-colors mb-2.5"
      >
        <Plus size={15} /> Invite to squad
      </button>
      <button
        onClick={handleLeave}
        disabled={leaving}
        className="w-full py-3 rounded-2xl text-[#FF6B4A] font-bold text-[12.5px] flex items-center justify-center gap-1.5 hover:bg-white/[0.03] transition-colors"
      >
        {leaving ? <Loader2 size={14} className="animate-spin" /> : "Leave squad"}
      </button>

      {showModal && <SquadModal squad={squad} onClose={() => setShowModal(false)} onChanged={refresh} />}
    </div>
  );
}

// Uses the shared profile (GET /api/profile/me) for stats + real badge names.
function ProfileScreen({ profile, onLogout }) {
  return (
    <div className="px-1 pb-5">
      <div className="flex items-center gap-4 mb-6">
        <Avatar name={profile.name} size={60} />
        <div className="flex-1">
          <div className="text-white text-[19px] font-extrabold tracking-tight">{profile.name}</div>
          <div className="text-[#8B8F7A] text-[13px] mt-0.5">{profile.role === "student" ? "Student" : "Working professional"}</div>
        </div>
        <button onClick={onLogout} className="text-[#8B8F7A] p-2 rounded-full hover:bg-white/5" title="Log out">
          <LogOut size={18} />
        </button>
      </div>

      <div className="flex gap-2.5 mb-6">
        {[[String(profile.current_streak), "Streak"], [profile.total_xp.toLocaleString(), "Total XP"], [profile.squad_rank ? `#${profile.squad_rank}` : "—", "Squad rank"]].map(([v, l]) => (
          <div key={l} className="flex-1 bg-[#191C14] border border-[#2A2E20] rounded-2xl px-2 py-4 text-center">
            <div className="text-white font-extrabold text-[18px]">{v}</div>
            <div className="text-[#8B8F7A] text-[10.5px] mt-1">{l}</div>
          </div>
        ))}
      </div>

      <div className="mb-2.5 text-white font-bold text-[14px]">Badges</div>
      {profile.badges.length === 0 ? (
        <p className="text-[#9AA085] text-[13px]">Complete tasks and grow your streak to earn badges.</p>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          {profile.badges.map((label) => {
            const color = avatarColor(label);
            return (
              <div key={label} className="flex items-center gap-2.5 px-3.5 py-3 bg-[#191C14] border border-[#2A2E20] rounded-2xl">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${color}22` }}>
                  <Trophy size={15} style={{ color }} />
                </div>
                <span className="text-[#D6D9C9] text-[12px] font-bold leading-tight">{label}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function Wandel() {
  const [profile, setProfile] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [tab, setTab] = useState("home");

  useEffect(() => {
    const token = getToken();
    if (!token) {
      setAuthChecked(true);
      return;
    }
    getProfile()
      .then(setProfile)
      .catch(() => clearToken())
      .finally(() => setAuthChecked(true));
  }, []);

  const refreshProfile = async () => {
    try {
      const p = await getProfile();
      setProfile(p);
    } catch {
      // ignore transient refresh errors
    }
  };

  const handleLogout = () => {
    clearToken();
    setProfile(null);
    setTab("home");
  };

  if (!authChecked) {
    return (
      <div className="max-w-[380px] mx-auto min-h-[640px] bg-[#0F110C] font-sans rounded-[28px] overflow-hidden flex items-center justify-center border border-[#2A2E20] relative shadow-2xl">
        <Loader2 size={22} className="animate-spin text-[#C6FF3D]" />
      </div>
    );
  }

  return (
    <div className="max-w-[380px] mx-auto min-h-[640px] bg-[#0F110C] font-sans rounded-[28px] overflow-hidden flex flex-col border border-[#2A2E20] relative shadow-2xl">
      <div className="flex-1 px-5 pt-6 overflow-y-auto">
        {!profile ? (
          <Onboarding onDone={setProfile} />
        ) : tab === "home" ? (
          <HomeScreen profile={profile} refreshProfile={refreshProfile} />
        ) : tab === "leaderboard" ? (
          <LeaderboardScreen profile={profile} />
        ) : tab === "squad" ? (
          <SquadScreen profile={profile} />
        ) : (
          <ProfileScreen profile={profile} onLogout={handleLogout} />
        )}
      </div>
      {profile && <AIChatbot />}
      {profile && <NavBar tab={tab} setTab={setTab} />}
    </div>
  );
}

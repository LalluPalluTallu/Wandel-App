// Thin client for the FastAPI backend.
// Base URL can be overridden with VITE_API_BASE_URL in your .env (Vite convention).
const API_BASE =
  (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_API_BASE_URL) ||
  "http://localhost:8000/api";

const TOKEN_KEY = "wandel_token";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}
export function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}
export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function request(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth) {
    const token = getToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  }

  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (networkErr) {
    throw new ApiError(
      "Can't reach the server. Is the backend running at " + API_BASE + "?",
      0
    );
  }

  if (res.status === 204) return null;

  let data = null;
  try {
    data = await res.json();
  } catch {
    // no body
  }

  if (!res.ok) {
    const message =
      (data && (data.detail || data.message)) || `Request failed (${res.status})`;
    throw new ApiError(typeof message === "string" ? message : JSON.stringify(message), res.status);
  }

  return data;
}

// ---- Auth ----
export const registerUser = ({ name, email, password, role }) =>
  request("/auth/register", { method: "POST", auth: false, body: { name, email, password, role } });

export const loginUser = ({ email, password }) =>
  request("/auth/login", { method: "POST", auth: false, body: { email, password } });

export const getMe = () => request("/auth/me");

// ---- Profile ----
export const getProfile = () => request("/profile/me");

// ---- Tasks ----
export const getTasks = () => request("/tasks");
export const getTodayTask = () => request("/tasks/today");
export const completeTask = (taskId) => request(`/tasks/${taskId}/complete`, { method: "POST" });

// ---- Leaderboard ----
export const getLeaderboard = (view = "global") => request(`/leaderboard?view=${view}`);

// ---- Squads ----
export const getMySquad = () => request("/squads/mine");
export const createSquad = (name) => request("/squads", { method: "POST", body: { name } });
export const joinSquad = (invite_code) => request("/squads/join", { method: "POST", body: { invite_code } });
export const leaveSquad = () => request("/squads/leave", { method: "POST" });

// ---- Events (analytics / future ML training signal) ----
export const postEvent = (event_type, task_id = null, metadata = null) =>
  request("/events", { method: "POST", body: { event_type, task_id, metadata } });

export { ApiError };

// ---- Chat ----
export const sendChatMessage = (message) =>
  request("/chat", { method: "POST", body: { message }, auth: false });

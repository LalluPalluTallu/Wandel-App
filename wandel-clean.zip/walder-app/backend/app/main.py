from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine, SessionLocal
from app.seed import seed_data
from app.config import get_settings
from app.routers import (
    auth,
    tasks,
    profile,
    leaderboard,
    squads,
    events,
    recommendations,
    chat,
)

app = FastAPI(title="Walder API")

# Create database tables
Base.metadata.create_all(bind=engine)

# Seed baseline tasks/badges
try:
    db = SessionLocal()
    seed_data(db)
finally:
    try:
        db.close()
    except Exception:
        pass

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        *get_settings().cors_origin_list,
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API routers
app.include_router(
    auth.router,
    prefix="/api/auth",
    tags=["Authentication"],
)

app.include_router(
    tasks.router,
    prefix="/api/tasks",
    tags=["Tasks"],
)

app.include_router(
    profile.router,
    prefix="/api/profile",
    tags=["Profile"],
)

app.include_router(
    leaderboard.router,
    prefix="/api/leaderboard",
    tags=["Leaderboard"],
)

app.include_router(
    squads.router,
    prefix="/api/squads",
    tags=["Squads"],
)

app.include_router(
    events.router,
    prefix="/api/events",
    tags=["Events"],
)

app.include_router(
    recommendations.router,
    prefix="/api/recommendations",
    tags=["Recommendations"],
)

app.include_router(
    chat.router, 
    prefix="/api", 
    tags=["Chat"])


@app.get("/")
def root():
    return {"message": "Walder API is running"}

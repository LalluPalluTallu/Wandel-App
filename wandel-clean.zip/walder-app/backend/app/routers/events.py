import json
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..dependencies import get_current_user
from ..models import ActivityEvent, User
from ..schemas import EventCreate

router = APIRouter(tags=["events"])


@router.post("")
def create_event(payload: EventCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    event = ActivityEvent(user_id=user.id, event_type=payload.event_type, task_id=payload.task_id, metadata_json=json.dumps(payload.metadata or {}))
    db.add(event)
    db.commit()
    return {"ok": True}

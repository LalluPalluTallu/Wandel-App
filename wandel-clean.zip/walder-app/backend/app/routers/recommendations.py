from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..dependencies import get_current_user
from ..models import User
from ..schemas import RecommendationOut
from ..services.recommendation import recommend_task

router = APIRouter(tags=["recommendations"])


@router.get("/recommendation", response_model=RecommendationOut)
def recommendation(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    try:
        task, score, reason = recommend_task(db, user)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"task": task, "score": score, "reason": reason}

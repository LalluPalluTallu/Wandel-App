from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..database import get_db
from ..dependencies import get_current_user
from ..models import User, UserBadge
from ..schemas import ProfileOut
from ..services.game import squad_for_user, streaks, total_xp

router = APIRouter(tags=["profile"])


@router.get("/me", response_model=ProfileOut)
def profile(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    current, longest = streaks(db, user.id)
    squad = squad_for_user(db, user.id)
    squad_rank = None
    if squad:
        from ..services.squads import squad_member_rank
        squad_rank = squad_member_rank(db, squad.id, user.id)
    badges = db.scalars(select(UserBadge).where(UserBadge.user_id == user.id)).all()
    return ProfileOut(id=user.id, name=user.name, email=user.email, role=user.role, total_xp=total_xp(db, user.id), current_streak=current, longest_streak=longest, squad_rank=squad_rank, badges=[b.badge.name for b in badges])

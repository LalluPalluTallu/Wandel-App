from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..database import get_db
from ..dependencies import get_current_user
from ..models import Squad, SquadMember, User
from ..schemas import SquadCreate, SquadJoin, SquadMemberOut, SquadOut
from ..services.game import squad_for_user, total_xp
from ..services.squads import new_invite_code, squad_member_rank, squad_xp

router = APIRouter(tags=["squads"])


def serialize(db: Session, squad: Squad) -> SquadOut:
    members = db.scalars(select(SquadMember).where(SquadMember.squad_id == squad.id)).all()
    member_data = sorted([SquadMemberOut(user_id=m.user_id, name=m.user.name, xp=total_xp(db, m.user_id), rank=0) for m in members], key=lambda x: x.xp, reverse=True)
    for i, m in enumerate(member_data, start=1): m.rank = i
    return SquadOut(id=squad.id, name=squad.name, invite_code=squad.invite_code, rank=None, xp=squad_xp(db, squad.id), members=member_data)


@router.get("/mine", response_model=SquadOut | None)
def my_squad(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    squad = squad_for_user(db, user.id)
    return serialize(db, squad) if squad else None


@router.post("", response_model=SquadOut, status_code=201)
def create_squad(payload: SquadCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if squad_for_user(db, user.id):
        raise HTTPException(status_code=409, detail="You are already in a squad")
    squad = Squad(name=payload.name.strip(), invite_code=new_invite_code(db), created_by=user.id)
    db.add(squad)
    db.flush()
    db.add(SquadMember(squad_id=squad.id, user_id=user.id))
    db.commit()
    db.refresh(squad)
    return serialize(db, squad)


@router.post("/join", response_model=SquadOut)
def join_squad(payload: SquadJoin, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if squad_for_user(db, user.id):
        raise HTTPException(status_code=409, detail="You are already in a squad")
    squad = db.scalar(select(Squad).where(Squad.invite_code == payload.invite_code.strip().upper()))
    if not squad:
        raise HTTPException(status_code=404, detail="Invalid invite code")
    db.add(SquadMember(squad_id=squad.id, user_id=user.id))
    db.commit()
    return serialize(db, squad)


@router.post("/leave")
def leave_squad(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    membership = db.scalar(select(SquadMember).where(SquadMember.user_id == user.id))
    if not membership:
        raise HTTPException(status_code=404, detail="You are not in a squad")
    db.delete(membership)
    db.commit()
    return {"message": "Left squad"}

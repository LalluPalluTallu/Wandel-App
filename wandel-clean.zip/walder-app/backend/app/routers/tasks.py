from datetime import date
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ..database import get_db
from ..dependencies import get_current_user
from ..models import ActivityEvent, Task, TaskCompletion, User, XPTransaction
from ..schemas import CompleteTaskOut, RecommendationOut, TaskOut
from ..services.game import award_badges, streaks, total_xp
from ..services.recommendation import recommend_task

router = APIRouter(tags=["tasks"])


@router.get("", response_model=list[TaskOut])
def list_tasks(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.scalars(select(Task).where(Task.is_active.is_(True), Task.role.in_(["all", user.role])).order_by(Task.id)).all()


@router.get("/today", response_model=RecommendationOut)
def today_task(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    try:
        task, score, reason = recommend_task(db, user)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"task": task, "score": score, "reason": reason}


@router.post("/{task_id}/complete", response_model=CompleteTaskOut)
def complete_task(task_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    task = db.get(Task, task_id)
    if not task or not task.is_active or task.role not in ("all", user.role):
        raise HTTPException(status_code=404, detail="Task not found")
    today = date.today()
    existing = db.scalar(select(TaskCompletion).where(TaskCompletion.user_id == user.id, TaskCompletion.task_id == task_id, TaskCompletion.completed_date == today))
    if existing:
        current, longest = streaks(db, user.id)
        return CompleteTaskOut(task_id=task_id, completed=True, xp_awarded=0, total_xp=total_xp(db, user.id), current_streak=current, longest_streak=longest, already_completed=True)

    completion = TaskCompletion(user_id=user.id, task_id=task.id, completed_date=today, xp_awarded=task.xp)
    db.add(completion)
    db.add(XPTransaction(user_id=user.id, amount=task.xp, reason=f"Completed task: {task.title}"))
    db.add(ActivityEvent(user_id=user.id, task_id=task.id, event_type="task_completed"))
    db.commit()
    award_badges(db, user.id)
    db.commit()
    current, longest = streaks(db, user.id)
    return CompleteTaskOut(task_id=task_id, completed=True, xp_awarded=task.xp, total_xp=total_xp(db, user.id), current_streak=current, longest_streak=longest, already_completed=False)

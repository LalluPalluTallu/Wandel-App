from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ..database import get_db
from ..dependencies import get_current_user
from ..models import SquadMember, User, XPTransaction
from ..schemas import LeaderboardEntry

router = APIRouter(tags=["leaderboard"])


def global_rows(db: Session):
    return db.execute(
        select(User.id, User.name, func.coalesce(func.sum(XPTransaction.amount), 0).label("xp"))
        .outerjoin(XPTransaction, XPTransaction.user_id == User.id)
        .where(User.is_active.is_(True))
        .group_by(User.id)
        .order_by(func.coalesce(func.sum(XPTransaction.amount), 0).desc(), User.id.asc())
    ).all()


@router.get("", response_model=list[LeaderboardEntry])
def leaderboard(view: str = Query("global", pattern="^(global|squad)$"), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if view == "global":
        rows = global_rows(db)
    else:
        rows = db.execute(
            select(User.id, User.name, func.coalesce(func.sum(XPTransaction.amount), 0).label("xp"))
            .join(SquadMember, SquadMember.user_id == User.id)
            .outerjoin(XPTransaction, XPTransaction.user_id == User.id)
            .where(SquadMember.squad_id.in_(select(SquadMember.squad_id).where(SquadMember.user_id == user.id)))
            .group_by(User.id)
            .order_by(func.coalesce(func.sum(XPTransaction.amount), 0).desc(), User.id.asc())
        ).all()
    return [LeaderboardEntry(rank=i, user_id=r.id, name=r.name, xp=int(r.xp), me=r.id == user.id) for i, r in enumerate(rows, start=1)]

from google import genai
from app.config import get_settings


settings = get_settings()

client = genai.Client(api_key=settings.gemini_api_key)


def ask_gemini(message: str) -> str:
    response = client.models.generate_content(
        model="gemini-3.5-flash-lite",
        contents=message,
    )

    return response.text
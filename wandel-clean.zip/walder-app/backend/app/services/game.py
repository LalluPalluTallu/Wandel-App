from datetime import date, timedelta
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ..models import Badge, Squad, SquadMember, TaskCompletion, User, UserBadge, XPTransaction


def total_xp(db: Session, user_id: int) -> int:
    return int(db.scalar(select(func.coalesce(func.sum(XPTransaction.amount), 0)).where(XPTransaction.user_id == user_id)) or 0)


def completed_dates(db: Session, user_id: int) -> list[date]:
    rows = db.scalars(
        select(TaskCompletion.completed_date)
        .where(TaskCompletion.user_id == user_id)
        .distinct()
        .order_by(TaskCompletion.completed_date.desc())
    ).all()
    return list(rows)


def streaks(db: Session, user_id: int) -> tuple[int, int]:
    dates = completed_dates(db, user_id)
    if not dates:
        return 0, 0
    date_set = set(dates)
    today = date.today()
    current = 0
    cursor = today
    if cursor not in date_set:
        cursor -= timedelta(days=1)
    while cursor in date_set:
        current += 1
        cursor -= timedelta(days=1)
    longest = 0
    run = 0
    prev = None
    for d in sorted(date_set):
        if prev and d == prev + timedelta(days=1):
            run += 1
        else:
            run = 1
        longest = max(longest, run)
        prev = d
    return current, longest


def award_badges(db: Session, user_id: int) -> None:
    current, longest = streaks(db, user_id)
    xp = total_xp(db, user_id)
    completions = db.scalar(select(func.count(TaskCompletion.id)).where(TaskCompletion.user_id == user_id)) or 0
    rules = [
        ("7-day streak", "Complete activities for 7 consecutive days", current >= 7),
        ("First 10k steps", "Activity milestone badge", completions >= 10),
        ("Squad MVP", "Reach 5,000 XP", xp >= 5000),
        ("Early bird", "Earn your first 500 XP", xp >= 500),
    ]
    for name, description, eligible in rules:
        if not eligible:
            continue
        badge = db.scalar(select(Badge).where(Badge.name == name))
        if not badge:
            badge = Badge(name=name, description=description)
            db.add(badge)
            db.flush()
        exists = db.scalar(select(UserBadge).where(UserBadge.user_id == user_id, UserBadge.badge_id == badge.id))
        if not exists:
            db.add(UserBadge(user_id=user_id, badge_id=badge.id))


def squad_for_user(db: Session, user_id: int) -> Squad | None:
    return db.scalar(
        select(Squad).join(SquadMember, SquadMember.squad_id == Squad.id).where(SquadMember.user_id == user_id)
    )

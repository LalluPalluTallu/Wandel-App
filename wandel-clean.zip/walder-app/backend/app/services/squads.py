import secrets
import string
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ..models import Squad, SquadMember, XPTransaction


def new_invite_code(db: Session) -> str:
    alphabet = string.ascii_uppercase + string.digits
    while True:
        code = "WALDER-" + "".join(secrets.choice(alphabet) for _ in range(6))
        if not db.scalar(select(Squad.id).where(Squad.invite_code == code)):
            return code


def squad_xp(db: Session, squad_id: int) -> int:
    value = db.scalar(
        select(func.coalesce(func.sum(XPTransaction.amount), 0))
        .join(SquadMember, SquadMember.user_id == XPTransaction.user_id)
        .where(SquadMember.squad_id == squad_id)
    )
    return int(value or 0)


def squad_member_rank(db: Session, squad_id: int, user_id: int) -> int:
    members = db.scalars(select(SquadMember).where(SquadMember.squad_id == squad_id)).all()
    scores = []
    for m in members:
        xp = db.scalar(select(func.coalesce(func.sum(XPTransaction.amount), 0)).where(XPTransaction.user_id == m.user_id)) or 0
        scores.append((m.user_id, int(xp)))
    scores.sort(key=lambda x: x[1], reverse=True)
    for i, (uid, _) in enumerate(scores, start=1):
        if uid == user_id:
            return i
    return len(scores)

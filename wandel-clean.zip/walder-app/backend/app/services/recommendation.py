from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models import Task, TaskCompletion, User


def recommend_task(db: Session, user: User) -> tuple[Task, float, str]:
    tasks = db.scalars(
        select(Task).where(Task.is_active.is_(True), Task.role.in_(["all", user.role]))
    ).all()
    if not tasks:
        raise ValueError("No active tasks available")

    completed = {x for x in db.scalars(select(TaskCompletion.task_id).where(TaskCompletion.user_id == user.id)).all()}
    best = None
    best_score = -1.0
    for task in tasks:
        score = 0.50
        if task.id not in completed:
            score += 0.20
        if task.difficulty == "easy":
            score += 0.15
        if task.role == user.role:
            score += 0.10
        if task.category == "movement":
            score += 0.05
        if score > best_score:
            best_score = score
            best = task
    return best, round(best_score, 2), "Baseline recommendation; replace this scorer with the trained ML model later."

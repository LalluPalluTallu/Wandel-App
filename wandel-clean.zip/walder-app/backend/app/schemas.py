from datetime import date, datetime
from pydantic import BaseModel, ConfigDict, EmailStr, Field


class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    role: str = Field(pattern="^(student|working)$")


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    email: EmailStr
    role: str
    created_at: datetime


class ProfileOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: str
    total_xp: int
    current_streak: int
    longest_streak: int
    squad_rank: int | None
    badges: list[str]


class TaskOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    description: str | None
    xp: int
    category: str
    role: str
    difficulty: str


class CompleteTaskOut(BaseModel):
    task_id: int
    completed: bool
    xp_awarded: int
    total_xp: int
    current_streak: int
    longest_streak: int
    already_completed: bool


class LeaderboardEntry(BaseModel):
    rank: int
    user_id: int
    name: str
    xp: int
    me: bool


class SquadCreate(BaseModel):
    name: str = Field(min_length=2, max_length=80)


class SquadJoin(BaseModel):
    invite_code: str = Field(min_length=3, max_length=30)


class SquadMemberOut(BaseModel):
    user_id: int
    name: str
    xp: int
    rank: int


class SquadOut(BaseModel):
    id: int
    name: str
    invite_code: str
    rank: int | None
    xp: int
    members: list[SquadMemberOut]


class EventCreate(BaseModel):
    event_type: str = Field(min_length=2, max_length=50)
    task_id: int | None = None
    metadata: dict | None = None


class RecommendationOut(BaseModel):
    task: TaskOut
    score: float
    reason: str

from sqlalchemy import select
from sqlalchemy.orm import Session
from .models import Badge, Task


def seed_data(db: Session):
    if not db.scalar(select(Task.id).limit(1)):
        tasks = [
            Task(title="Walk to your farthest class", description="Add a little extra walking between classes.", xp=40, category="walking", role="student", difficulty="easy"),
            Task(title="Take a 5-min movement break", description="Stand up and move for five minutes.", xp=40, category="movement", role="student", difficulty="easy"),
            Task(title="Campus walking challenge", description="Take a purposeful walk across campus.", xp=50, category="walking", role="student", difficulty="medium"),
            Task(title="Take a 5-min walk between meetings", description="Use a meeting gap for a short walk.", xp=40, category="walking", role="working", difficulty="easy"),
            Task(title="Stand and move for 5 minutes", description="Break up desk time with light movement.", xp=40, category="movement", role="working", difficulty="easy"),
            Task(title="Walk during your lunch break", description="Take a short walk during lunch.", xp=50, category="walking", role="working", difficulty="medium"),
            Task(title="5-minute movement break", description="Stand up and move for five minutes.", xp=40, category="movement", role="all", difficulty="easy"),
        ]
        db.add_all(tasks)
    if not db.scalar(select(Badge.id).limit(1)):
        db.add_all([
            Badge(name="7-day streak", description="Complete activities for 7 consecutive days"),
            Badge(name="First 10k steps", description="Activity milestone badge"),
            Badge(name="Squad MVP", description="Reach 5,000 XP"),
            Badge(name="Early bird", description="Earn your first 500 XP"),
        ])
    db.commit()
